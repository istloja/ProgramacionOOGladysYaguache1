
package Drportes_serealizable;

import java.io.Serializable;


public class liga implements Serializable{
    
}
