
package Drportes_serealizable;

import java.io.Serializable;


public class confederacion implements Serializable {
    
    
}
