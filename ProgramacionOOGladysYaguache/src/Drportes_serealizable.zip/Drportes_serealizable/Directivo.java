
package Drportes_serealizable;


public class Directivo {
    
}
