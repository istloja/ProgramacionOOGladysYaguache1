
package Drportes_serealizable;

import java.io.Serializable;


public class equipo implements Serializable {
    private String nombre;
    private String color;
    private int numero_jugador;
    private String director;
    private futbolista futbolista;

    public equipo() {
    }


    public equipo(String nombre, String color, int numero_jugador, String director, futbolista futbolista) {
        this.nombre = nombre;
        this.color = color;
        this.numero_jugador = numero_jugador;
        this.director = director;
        this.futbolista = futbolista;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getNumero_jugador() {
        return numero_jugador;
    }

    public void setNumero_jugador(int numero_jugador) {
        this.numero_jugador = numero_jugador;
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public futbolista getFutbolista() {
        return futbolista;
    }

    public void setFutbolista(futbolista futbolista) {
        this.futbolista = futbolista;
    }
    public static void main(String[] args) {
    equipo obj = new equipo ("ganadores","rojo", 22, "Roberto Sanchez", new futbolista("Juan", "Calle", 10, "Delantero", 128.5));
    }
}

    
    

    

    
   
